from PyQt5 import QtCore, QtGui, QtWidgets
import random
import time

#class for the window
class Ui_MainWindow():
    #this is in place of the def __init__
    def setupUi(self, MainWindow):
        #classes file list
        self.animals = ["cuteCat1.jpg","cuteCorgi.jpg","cutePony.jpg","cuteRabbit.jpg","cuteHamster.jpg","cuteLamb.jpg",]
        #starting place in file selection
        self.image = random.randint(0,5)
        #name of window
        MainWindow.setObjectName("MainWindow")
        #size of window
        MainWindow.resize(950, 900)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        #main "label" to hold the picture
        self.photo = QtWidgets.QLabel(self.centralwidget)
        #giving the label location x,y then size x,y
        self.photo.setGeometry(QtCore.QRect(225, 10, 450, 450))
        #obligatory text but none as its an image
        self.photo.setText("")
        #give value of a random pic in the file
        self.photo.setPixmap(QtGui.QPixmap(self.animals[self.image]))
        #scale image to the label size
        self.photo.setScaledContents(True)
        #give label name
        self.photo.setObjectName("placeholder")
        #button for each choice
        self.cat = QtWidgets.QPushButton(self.centralwidget)
        #all have location x,y and size x,y
        self.cat.setGeometry(QtCore.QRect(50, 500, 250, 125))
        #all have name relative to their "value"
        self.cat.setObjectName("Cat")
        self.dog = QtWidgets.QPushButton(self.centralwidget)
        self.dog.setGeometry(QtCore.QRect(350, 500, 250, 125))
        self.dog.setObjectName("Dog")
        self.horse = QtWidgets.QPushButton(self.centralwidget)
        self.horse.setGeometry(QtCore.QRect(650, 500, 250, 125))
        self.horse.setObjectName("Horse")
        self.rabbit = QtWidgets.QPushButton(self.centralwidget)
        self.rabbit.setGeometry(QtCore.QRect(50, 700, 250, 125))
        self.rabbit.setObjectName("Rabbit")
        self.hamster = QtWidgets.QPushButton(self.centralwidget)
        self.hamster.setGeometry(QtCore.QRect(350, 700, 250, 125))
        self.hamster.setObjectName("Hamster")
        self.sheep = QtWidgets.QPushButton(self.centralwidget)
        self.sheep.setGeometry(QtCore.QRect(650, 700, 250, 125))
        self.sheep.setObjectName("Sheep")
        MainWindow.setCentralWidget(self.centralwidget)
        #obligatory menubar and statusbar, not relavent to this file
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 572, 22))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)
        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)
        
        #if said button is pressed, reurn a place in the array using lambda as its hard to pass things through
        self.cat.clicked.connect(lambda: self.guess(0))
        self.dog.clicked.connect(lambda: self.guess(1))
        self.horse.clicked.connect(lambda: self.guess(2))
        self.rabbit.clicked.connect(lambda: self.guess(3))
        self.hamster.clicked.connect(lambda: self.guess(4))
        self.sheep.clicked.connect(lambda: self.guess(5))
    
    #giveing values to buttons & windows
    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.cat.setText(_translate("MainWindow", "This is a cat"))
        self.dog.setText(_translate("MainWindow", "This is a dog"))
        self.horse.setText(_translate("MainWindow", "This is a horse"))
        self.hamster.setText(_translate("MainWindow", "This is a hamster"))
        self.sheep.setText(_translate("MainWindow", "This is a sheep"))
        self.rabbit.setText(_translate("MainWindow", "This is a rabbit"))
        
    #checks if the button matches image
    def guess(self,num):
        #if yes, change the image randomly
        if self.image == num:
            self.image = random.randint(0,5)
            self.photo.setPixmap(QtGui.QPixmap(self.animals[self.image]))
        else:
            pass
        
            
            
        

#creates an instance and runs code
if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
